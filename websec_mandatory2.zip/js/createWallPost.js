$(document).ready(function() {
    $(document).on('click', '.createWallPost', function() {
        window.location.replace('../normalUser/createWallPost.php');
    });

    // $(document).on('click', '.replyToWallPost', function() {
    //     window.location.replace('../normalUser/replyWallPost.php');
    // });
});