$(document).ready(function() {
    $(document).on('click', '.updateReply', function() {
        window.location.replace('../normalUser/updateReply.php');
    });

    // $(document).on('click', '.replyToWallPost', function() {
    //     window.location.replace('../normalUser/replyWallPost.php');
    // });
});