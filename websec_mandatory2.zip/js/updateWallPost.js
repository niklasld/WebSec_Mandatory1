$(document).ready(function() {
    $(document).on('click', '.updateWallPost', function() {
        window.location.replace('../normalUser/updateWallPost.php');
    });

    // $(document).on('click', '.replyToWallPost', function() {
    //     window.location.replace('../normalUser/replyWallPost.php');
    // });
});