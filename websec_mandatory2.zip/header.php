<div xmlns="http://www.w3.org/1999/html">
    <nav class="navbar navbar-expand-sm bg-dark navbar-dark fixed-top">
        <!-- Brand/logo -->
        <div class="container">

            <!-- Links -->
            <ul class="navbar-nav mr-5">
                <li class="nav-item">
                    <a class="nav-link" href="../normalUser/wallView.php">Front Page</a>
                </li>

                <li class="nav-item">
                <a class="nav-link" href="../normalUser/generalFunctions/signOut.php">Sign out</a>
                </li>

            </ul>
        </div>
    </nav>
</div>
