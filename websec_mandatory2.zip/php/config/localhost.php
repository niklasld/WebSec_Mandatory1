<?php
    function getLocalhost() {
        $localhost = false;

        return $localhost;
    }
?>